package com.example.humanagesassigment;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    //the view to be clicked
    TextView humanButton;
    //the value that tracks what position in the arraylists below to use
    int counter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        humanButton = findViewById(R.id.humanText);

        humanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //list of the String of stages of human development, in order
                ArrayList<String> humanList = new ArrayList<String>();
                humanList.add(getResources().getString(R.string.newBorn_text));
                humanList.add(getResources().getString(R.string.toddler_text));
                humanList.add(getResources().getString(R.string.child_text));
                humanList.add(getResources().getString(R.string.teenager_text));
                humanList.add(getResources().getString(R.string.adult_text));
                humanList.add(getResources().getString(R.string.elder_text));
                humanList.add(getResources().getString(R.string.rip_text));
                humanList.add(getResources().getString(R.string.goAgain_text));

                //list of the corresponding colors of human development, in order
                ArrayList<Integer> colorList = new ArrayList<Integer>();
                colorList.add(getResources().getColor(R.color.newBorn_Color));
                colorList.add(getResources().getColor(R.color.toddler_Color));
                colorList.add(getResources().getColor(R.color.child_Color));
                colorList.add(getResources().getColor(R.color.teenager_Color));
                colorList.add(getResources().getColor(R.color.adult_Color));
                colorList.add(getResources().getColor(R.color.elder_Color));
                colorList.add(getResources().getColor(R.color.rip_Color));
                colorList.add(getResources().getColor(R.color.startAgain_Color));



                //keep track of the position in the ArrayList to shuffle to the next one
                //keep less than the size of the arrayLists
                ++counter;
                counter %= humanList.size();
                //text is what the textView currently says
                String text = "";
                int color = 0;

                //set the text and color based on the counter value
                text = humanList.get(counter);
                color = colorList.get(counter);
                humanButton.setText(text);
                humanButton.setTextColor(color);
            }
        });

    }
}
